#!/usr/bin/python

subdivisions = 3
frequency = 


